

#include <string>        // Text strings ability
#include <fstream>      // File streaming ability
#include <iostream>    // input/output streaming ability
#include <iomanip>    //  input/output manipulation ability
#include <vector>    // vectors for stretching arrays ability
#include <regex>    // regular expression matching text
#include <msclr/marshal_cppstd.h> // converts system string to std string
#pragma once


using namespace std;
using namespace System::IO;
vector<string> songVector;
namespace GMP3 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}

	protected:

	private: System::Windows::Forms::Button^  GetMP3button;

	private: System::Windows::Forms::Button^  ViewButton;
	protected:

	protected:

	protected:





	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::Label^  StatusLabel;
	private: System::Windows::Forms::Button^  viewAlpha;
	private: System::Windows::Forms::Button^  Sort;









	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->GetMP3button = (gcnew System::Windows::Forms::Button());
			this->ViewButton = (gcnew System::Windows::Forms::Button());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->StatusLabel = (gcnew System::Windows::Forms::Label());
			this->viewAlpha = (gcnew System::Windows::Forms::Button());
			this->Sort = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// GetMP3button
			// 
			this->GetMP3button->Location = System::Drawing::Point(36, 22);
			this->GetMP3button->Name = L"GetMP3button";
			this->GetMP3button->Size = System::Drawing::Size(96, 36);
			this->GetMP3button->TabIndex = 4;
			this->GetMP3button->Text = L"Get MP3 List";
			this->GetMP3button->UseVisualStyleBackColor = true;
			this->GetMP3button->Click += gcnew System::EventHandler(this, &MyForm::getData_Click);
			// 
			// ViewButton
			// 
			this->ViewButton->Location = System::Drawing::Point(36, 64);
			this->ViewButton->Name = L"ViewButton";
			this->ViewButton->Size = System::Drawing::Size(96, 38);
			this->ViewButton->TabIndex = 5;
			this->ViewButton->Text = L"View MP3 List";
			this->ViewButton->UseVisualStyleBackColor = true;
			this->ViewButton->Click += gcnew System::EventHandler(this, &MyForm::viewData_Click);
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(36, 132);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(265, 20);
			this->textBox1->TabIndex = 6;
			this->textBox1->Text = L"F:\\MyMusic";
			this->textBox1->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox1_TextChanged);
			// 
			// StatusLabel
			// 
			this->StatusLabel->AutoSize = true;
			this->StatusLabel->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->StatusLabel->Location = System::Drawing::Point(33, 168);
			this->StatusLabel->Name = L"StatusLabel";
			this->StatusLabel->Size = System::Drawing::Size(105, 13);
			this->StatusLabel->TabIndex = 7;
			this->StatusLabel->Text = L"Status is shown here";
			this->StatusLabel->Click += gcnew System::EventHandler(this, &MyForm::Status_Click);
			// 
			// viewAlpha
			// 
			this->viewAlpha->Location = System::Drawing::Point(179, 64);
			this->viewAlpha->Name = L"viewAlpha";
			this->viewAlpha->Size = System::Drawing::Size(96, 38);
			this->viewAlpha->TabIndex = 8;
			this->viewAlpha->Text = L"View Alpha List";
			this->viewAlpha->UseVisualStyleBackColor = true;
			this->viewAlpha->Click += gcnew System::EventHandler(this, &MyForm::viewAlpha_Click);
			// 
			// Sort
			// 
			this->Sort->Location = System::Drawing::Point(179, 22);
			this->Sort->Name = L"Sort";
			this->Sort->Size = System::Drawing::Size(96, 35);
			this->Sort->TabIndex = 9;
			this->Sort->Text = L"Sort MP3 List";
			this->Sort->UseVisualStyleBackColor = true;
			this->Sort->Click += gcnew System::EventHandler(this, &MyForm::Sort_Click);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ButtonFace;
			this->ClientSize = System::Drawing::Size(326, 211);
			this->Controls->Add(this->Sort);
			this->Controls->Add(this->viewAlpha);
			this->Controls->Add(this->StatusLabel);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->ViewButton);
			this->Controls->Add(this->GetMP3button);
			this->Name = L"MyForm";
			this->Text = L"MP3 List by Tracy Rose";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

	private: System::Void MyForm_Load(System::Object^  sender, System::EventArgs^  e) 
	{

	}

	private: System::Void getData_Click(System::Object^  sender, System::EventArgs^  e) // GET list button
	{
		//****************GET DATA *************************************
		//**************************************************************
		//**************************************************************
		vector<string> songVector;
		vector<string> artistVector;
		String ^ inputText = textBox1-> Text;  // Take inputText from textBox1 area in dialogue box

		std::string filePath = msclr::interop::marshal_as< std::string >(inputText);
		string str1 = "dir \"" + filePath + "\" /s > MusicData.txt";  //   The backslash after first quotes escapes the second quotes to use filepath with space characters

		const char *command = str1.c_str();  // Convert previous string to const char * because system requires parameter of type const char 
		system(command);  // 'command' is the const version of path name

		StatusLabel -> Text = "Wrote file MusicData.txt" ;

	}





	private: System::Void viewData_Click(System::Object^  sender, System::EventArgs^  e) // View DATA in notepad button
	{
		StatusLabel->Text = "Working...";
		string s;
		s = "notepad.exe MusicData.txt";
		system(s.c_str());
		
	
	}

	private: System::Void viewAlpha_Click(System::Object^  sender, System::EventArgs^  e) 
	{
		StatusLabel->Text = "ALPHABETIZING...";
		string s;
		s = "notepad.exe AlphabetizedSongs.txt";
		system(s.c_str());

	}


	private: System::Void textBox1_TextChanged(System::Object^  sender, System::EventArgs^  e) 
	{
	//Textbox1 input text area
	}

	private: System::Void Status_Click(System::Object^  sender, System::EventArgs^  e)
	{
	// Status display area
	}





private: System::Void Sort_Click(System::Object^  sender, System::EventArgs^  e)
{
	//****************SORT DATA *********** ************************
	//**************************************************************
	//**************************************************************
	
	StatusLabel->Text = "SORTING...";
	ifstream infile;
	string fullString;
	infile.open("MusicData.txt");  // Open the file to READ
	bool found;
	int i = 0;
	while (!infile.eof())
	{
		getline(infile, fullString);
		found = false;
		// Using Regular Expressions to find only MP3 song in text
		smatch m; // Match or   typedef std::match_results<string>
		regex e(".mp3", regex_constants::icase);
		found = regex_search(fullString, m, e);  // input string, results are m, search is e defined above it.

		if (found == true)
		{
			fullString.erase(0, 38); // Erases the date, time, and file size of the original MP3 list
			songVector.push_back(fullString);  // Sends the song info to be stored by the vector array

		}

	}  // END OF large read file WHILE loop

	StatusLabel->Text = "Done reading-in the data that will be alphabetized...";


	//****************ALPHABETIZE BY ARTIST ************************
	//**************************************************************
	//**************************************************************

	// temporary variables used in bubble sorting artists/songs
	int j;
	string song1;
	string song2;


	// This section provides a Bubble sort by ARTIST where A is at the bottom
	// and Z is at the top
	for (i = 0; i < songVector.size(); ++i)
	{
		for (j = 0; j < (songVector.size() - i - 1); ++j)
		{

			// assign two side-by-side elements for bubble sort compare
			song1 = songVector[j];
			song2 = songVector[j + 1];

			//**************************************************************
			// Compare data values and switch  j > j+1.
			//**************************************************************
			if (song1 > song2)
			{
				// Swap the vector contents if the first one is larger making it all A-->B order
				swap(songVector[j], songVector[j + 1]); // put song contents of element #1 into slot #2
			}
		}
	}

	StatusLabel->Text = "Done alphabetizing!!  Now writing to new file";

	//**************** WRITING TO HARD DRIVE ***********************
	//**************************************************************
	//**************************************************************


	// creates the banner for the file output
	ofstream outfile;
	outfile.open("AlphabetizedSongs.txt");    // Open the file to WRITE
	outfile << "===========================================================================================================" << endl;


	for (i = 0; i < songVector.size(); ++i)
	{

		song1 = songVector[i];
		outfile << i << " " << song1 << endl;

	} // end of FOR loop


	infile.close(); //close input file
	outfile.close(); //close output file
	StatusLabel->Text = " [Complete] Alphabetizing written to file";

	//******************************************************************************************
}  // end of sort routine

};
}


