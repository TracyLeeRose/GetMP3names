

#include <string>        // Text strings ability
#include <fstream>      // File streaming ability
#include <iostream>    // input/output streaming ability
#include <iomanip>    //  input/output manipulation ability
#include <vector>    // vectors for stretching arrays ability
#include <regex>    // regular expression matching text
#include <msclr/marshal_cppstd.h> // converts system string to std string
#pragma once


using namespace std;
using namespace System::IO;
vector<string> songVector;
namespace GMP3 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;


	/// Summary for MyForm

	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//TODO: Add the constructor code here

		}

	protected:
		/// Clean up any resources being used.

		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}

	protected:
	private: System::Windows::Forms::Button^  GetMP3button;
	private: System::Windows::Forms::Button^  ViewButton;
	protected:
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::Label^  StatusLabel;
	private: System::Windows::Forms::Button^  viewAlpha;
	private: System::Windows::Forms::Button^  Sort;
	private: System::Windows::Forms::OpenFileDialog^ openFileDialog1;



	private:

		/// Required designer variable.
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.

		void InitializeComponent(void)
		{
			this->GetMP3button = (gcnew System::Windows::Forms::Button());
			this->ViewButton = (gcnew System::Windows::Forms::Button());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->StatusLabel = (gcnew System::Windows::Forms::Label());
			this->viewAlpha = (gcnew System::Windows::Forms::Button());
			this->Sort = (gcnew System::Windows::Forms::Button());
			this->openFileDialog1 = (gcnew System::Windows::Forms::OpenFileDialog());
			this->SuspendLayout();
			// 
			// GetMP3button
			// 
			this->GetMP3button->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->GetMP3button->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->GetMP3button->Location = System::Drawing::Point(36, 22);
			this->GetMP3button->Name = L"GetMP3button";
			this->GetMP3button->Size = System::Drawing::Size(96, 36);
			this->GetMP3button->TabIndex = 4;
			this->GetMP3button->Text = L"Get MP3 List";
			this->GetMP3button->UseVisualStyleBackColor = false;
			this->GetMP3button->Click += gcnew System::EventHandler(this, &MyForm::getData_Click);
			// 
			// ViewButton
			// 
			this->ViewButton->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->ViewButton->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->ViewButton->Location = System::Drawing::Point(57, 73);
			this->ViewButton->Name = L"ViewButton";
			this->ViewButton->Size = System::Drawing::Size(96, 19);
			this->ViewButton->TabIndex = 5;
			this->ViewButton->Text = L"View MP3 List";
			this->ViewButton->UseVisualStyleBackColor = false;
			this->ViewButton->Click += gcnew System::EventHandler(this, &MyForm::viewData_Click);
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(36, 132);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(265, 20);
			this->textBox1->TabIndex = 6;
			this->textBox1->Text = L"F:\\LawnMusic";
			// 
			// StatusLabel
			// 
			this->StatusLabel->AutoSize = true;
			this->StatusLabel->BackColor = System::Drawing::SystemColors::Info;
			this->StatusLabel->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->StatusLabel->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->StatusLabel->Location = System::Drawing::Point(36, 168);
			this->StatusLabel->Name = L"StatusLabel";
			this->StatusLabel->Size = System::Drawing::Size(179, 22);
			this->StatusLabel->TabIndex = 7;
			this->StatusLabel->Text = L"Status is shown here";
			this->StatusLabel->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
			// 
			// viewAlpha
			// 
			this->viewAlpha->Location = System::Drawing::Point(205, 73);
			this->viewAlpha->Name = L"viewAlpha";
			this->viewAlpha->Size = System::Drawing::Size(96, 19);
			this->viewAlpha->TabIndex = 8;
			this->viewAlpha->Text = L"View Alpha List";
			this->viewAlpha->UseVisualStyleBackColor = true;
			this->viewAlpha->Click += gcnew System::EventHandler(this, &MyForm::viewAlpha_Click);
			// 
			// Sort
			// 
			this->Sort->Location = System::Drawing::Point(179, 22);
			this->Sort->Name = L"Sort";
			this->Sort->Size = System::Drawing::Size(96, 35);
			this->Sort->TabIndex = 9;
			this->Sort->Text = L"Sort MP3 List";
			this->Sort->UseVisualStyleBackColor = true;
			this->Sort->Click += gcnew System::EventHandler(this, &MyForm::Sort_Click);
			// 
			// openFileDialog1
			// 
			this->openFileDialog1->FileName = L"openFileDialog1";
			this->openFileDialog1->FileOk += gcnew System::ComponentModel::CancelEventHandler(this, &MyForm::openFileDialog1_FileOk);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ButtonFace;
			this->ClientSize = System::Drawing::Size(486, 325);
			this->Controls->Add(this->Sort);
			this->Controls->Add(this->viewAlpha);
			this->Controls->Add(this->StatusLabel);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->ViewButton);
			this->Controls->Add(this->GetMP3button);
			this->Name = L"MyForm";
			this->Text = L"MP3 List by Tracy Rose";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

	private: System::Void MyForm_Load(System::Object^  sender, System::EventArgs^  e) 
	{

	}

	private: System::Void getData_Click(System::Object^  sender, System::EventArgs^  e) // GET list button
	{
		//****************GET DATA *************************************
		//**************************************************************
		
		vector<string> songVector;
		vector<string> artistVector;
		String ^ inputText = textBox1-> Text;  // Take inputText from textBox1 area in dialogue box

		std::string filePath = msclr::interop::marshal_as< std::string >(inputText);
		string str1 = "dir \"" + filePath + "\" /s > MusicData.txt";  //   The backslash after first quotes escapes the second quotes to use filepath with space characters

		const char *command = str1.c_str();  // Convert previous string to const char * because system requires parameter of type const char 
		system(command);  // 'command' is the const version of path name

		Beep(523, 500); // 523 hertz (C5) for 500 milliseconds
		StatusLabel -> Text = "Wrote file MusicData.txt" ;

	}


	//***************************************************************************
	//***** Opens NOTEPAD and shows intial list from MP3 directory in DOS ******
    //***************************************************************************
	private: System::Void viewData_Click(System::Object^  sender, System::EventArgs^  e) // View DATA in notepad button
	{
		Beep(523, 500); // 523 hertz (C5) for 500 milliseconds
		StatusLabel->Text = "Notepad Viewed";
		string s;
		s = "notepad.exe MusicData.txt";
		system(s.c_str());
	
	}

private: System::Void Sort_Click(System::Object^  sender, System::EventArgs^  e)
{
		
	//**************** BUBBLE SORT DATA ************************
	//**********************************************************
	StatusLabel->Text = " SORTING This is the status ";
	Beep(500, 200); // 500 hertz (C5) for 200 milliseconds
	Beep(400, 200); // 400 hertz (C5) for 200 milliseconds
	Beep(300, 200); // 300 hertz (C5) for 200 milliseconds


	ifstream infile;
	string fullString;
	infile.open("MusicData.txt");  // Open the file to READ
	
	bool found;
	int i = 0;
		
	while (!infile.eof())
	{
		getline(infile, fullString);
		found = false;
		// Using Regular Expressions to find only MP3 song in text
		smatch m; // Match or   typedef std::match_results<string>
		regex e(".mp3", regex_constants::icase);
		found = regex_search(fullString, m, e);  // input string, results are m, search is e defined above it.

		if (found == true)
		{
			fullString.erase(0, 38); // Erases the date, time, and file size of the original MP3 list
			songVector.push_back(fullString);  // Sends the song info to be stored by the vector array

		}
	}  // END OF large read file WHILE loop


	//****************ALPHABETIZE BY ARTIST ************************
	//**************************************************************
	
	// temporary variables used in bubble sorting artists/songs
	int j;

	// This section provides a Bubble sort by ARTIST where A is at the bottom
	// and Z is at the top initially
	for (i = 0; i < songVector.size(); ++i)
	{
		for (j = 0; j < (songVector.size() - i - 1); ++j)
		{

			//**************************************************************
			// Compare data values and switch vector arrays when needed
			//**************************************************************
			if (songVector[j] > songVector[j + 1])
			{
				// Swap the vector contents if the first one is larger making it all A-->B order
				swap(songVector[j], songVector[j + 1]); // put song contents of element #1 into slot #2
			}
		}
	} //end of Bubble sort FOR loop



	//**************** WRITING TO HARD DRIVE ***********************
	//**************************************************************
	

	// creates the banner for the file output
	ofstream outfile;
	outfile.open("AlphabetizedSongs.txt");    // Open the file to WRITE
	outfile << "===========================================================================================================" << endl;


	for (i = 0; i < songVector.size(); ++i)
	{
	
		outfile << i << " " << songVector[i] << endl;

	} // end of FOR loop


	infile.close(); //close input file
	outfile.close(); //close output file
	Beep(300, 200); // 300 hertz (C5) for 200 milliseconds
	Beep(400, 200); // 400 hertz (C5) for 200 milliseconds
	Beep(500, 200); // 500 hertz (C5) for 200 milliseconds
	StatusLabel->Text = " Alphabetized Data To File";

	//The songVector.clear() <-- clears the Vector just in case SORT is pushed again.
	// thereby avoids duplicates in the text file
	songVector.clear(); 

}  // end of sort routine

	//***************************************************************************
	//***** Opens NOTEPAD and shows FINAL list sorted Alphabetically ************
	//***************************************************************************
	private: System::Void viewAlpha_Click(System::Object^ sender, System::EventArgs^ e)
	{
		Beep(523, 500); // 523 hertz (C5) for 500 milliseconds
		StatusLabel->Text = "All Bubble Sorting Complete";
		string s;
		s = "notepad.exe AlphabetizedSongs.txt";
		system(s.c_str());
	}



private: System::Void pictureBox1_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void openFileDialog1_FileOk(System::Object^ sender, System::ComponentModel::CancelEventArgs^ e) {
}
};
}


