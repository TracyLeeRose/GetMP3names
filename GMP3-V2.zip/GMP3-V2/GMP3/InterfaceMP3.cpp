#include "InterfaceMP3.h"

using namespace System;
using namespace System::Windows::Forms;

[STAThread]



void main()
{
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	GMP3::MyForm form;
	Application::Run(%form);
	
}

